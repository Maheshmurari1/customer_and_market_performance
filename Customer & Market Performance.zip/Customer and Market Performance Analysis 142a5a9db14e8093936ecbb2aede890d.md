# Customer and Market Performance Analysis

To evaluate **customer performance** and **market performance** by analyzing key metrics such as **sales**, **gross margin**, and **net sales**. The goal is to provide actionable insights that drive strategic decision-making and improve overall business profitability.

# 1.About Me

**As a Data Analyst with a background in At-liq Hardware, I bring a strong analytical skill set, particularly in Excel, Power Query, SQL, and Power BI.**

I have experience managing and analyzing large data sets, where I’ve developed impactful solutions such as:

- **Sales and Market Analysis**,
- **Financial Analysis Excel Reports**, and
- **Dynamic Dashboards for Business Intelligence 360**These contributions have empowered users to make well-informed decisions.

**Certified in "Mother of Business with Excel" by Code basics**, I specialize in:

- **Data Cleaning**,
- **Visualization**, and
- **Storytelling**

I excel at translating complex data insights into actionable recommendations, driving meaningful business outcomes.

# 2.About the Project

- Analyze **sales**, **gross margin**, and **net sales**.
- Evaluate **customer performance**, including high-performing and under performing customers.
- Assess **market performance** across different regions or segments.
- Identify **trends and growth opportunities** in sales and profitability.
- Provide **detailed reports** with actionable recommendations.
- Track performance **comparisons** (e.g., year-over-year,Quarter-over-Quarter )

To help them, I conducted an Analysis and shared the results with them. 

Below , you can find how I did this,

Thank you.

# 3.Objectives and Context

This project is about At-liq Hardware .The Analysis includes different aspects of Customer and Market Performance. Mr.Haryali [Manger] asked about Customer and Market Performance . 

So, I gathered information for them.

## 4.Data Preparation and Process

Data Gathering

![Concept map.png](Concept_map.png)

## Data Cleaning Steps

Transformed Data Types, removed duplicates,Modified columns and replaced Erroneous values without Justifying why these steps Matter.

![Screenshot 2024-11-16 220739.png](Screenshot_2024-11-16_220739.png)

- Data cleaning in Power Query is the process of identifying and fixing **inaccuracies**, inconsistencies, and errors in data, ensuring it is accurate, consistent, and ready for analysis and reporting.

### Data Modeling with Relationships

A **data model** defines the structure of data and how different data entities are related. In Excel, relationships between tables allow seamless integration of data for efficient analysis and reporting.

![Screenshot 2024-11-17 080528.png](Screenshot_2024-11-17_080528.png)

# 5.Key Finding

1.What are the top 10 products based on the percentage increase in their net sales from 2020 to 2021?

![Screenshot 2024-11-18 150737.png](Screenshot_2024-11-18_150737.png)

2.What are the new products that Atliq began selling in 2021?

![Screenshot 2024-11-18 150921.png](Screenshot_2024-11-18_150921.png)

3.What are the top 5 countries in terms of net sales in 2021?

![Screenshot 2024-11-18 151054.png](Screenshot_2024-11-18_151054.png)

## 5.**Customer & Market Performance Analysis Reports** 📊

I recently worked on creating comprehensive analysis reports focusing on **customer performance** and **market trends**. These reports dive deep into actionable insights that drive strategic decisions, including:

✅ **Customer Behavior Analysis**: Segmenting customer demographics, purchasing patterns, and retention rates to highlight key growth opportunities.

✅ **Market Performance Evaluation**: Identifying high-performing markets, untapped potential, and trends shaping the industry landscape.

[MarketPerformance.pdf](p1.pdf)

[customerPerformance.pdf](cust.pdf)

# **6.Conclusion**

Using advanced Excel tools such as **Power Query**, **Power Pivot**, and **DAX**, this analysis uncovered:

- **Key insights into customer behavior**: Identifying high-value segments and retention opportunities.
- **Market dynamics**: Highlighting trends and opportunities in high-growth areas.
- **Product performance optimization**: Pinpointing areas for improved efficiency and profitability.

These insights provide actionable guidance to:

- Support strategic decision-making.
- Drive customer engagement and retention.
- Foster sustained business growth in a competitive market.